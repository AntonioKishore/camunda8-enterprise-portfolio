# Education

Add the approved Education-domain projects here. For every project, create a numbered project folder with `bpmn-models/`, `backend-springboot/`, and `frontend-react/` subfolders.
